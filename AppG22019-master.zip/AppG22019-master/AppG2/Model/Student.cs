﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppG2.Model
{
    public class Student
    {
        [Key]
        public string IDStudent { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public GENDER Gender { get; set; }
        public DateTime DOB { get; set; }
        public string POB { get; set; }

        public ICollection<HistoryLearning> ListHistoryLearning { get; set; }
    }
    public enum GENDER
    {
        Male, Female, Other
    }
}
