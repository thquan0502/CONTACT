﻿namespace AppG2.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<AppG2.Model.AppG2Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(AppG2.Model.AppG2Context context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.
            context.StudentDbset.AddOrUpdate(
                new Model.Student
                {
                    IDStudent = "102T101",
                    FirstName = "Zũng",
                    LastName = "Nguyễn",
                    DOB = new DateTime(1990, 2, 2),
                    Gender = Model.GENDER.Male,
                    POB = "Thừa Thiên Huế"
                },
                new Model.Student
                {
                    IDStudent = "102T102",
                    FirstName = "Xoang",
                    LastName = "Nguyễn Thị",
                    DOB = new DateTime(1990, 3, 2),
                    Gender = Model.GENDER.Female,
                    POB = "Đà Nẵng"
                }
                );
            context.SaveChanges();

            for (int i = 1; i <= 12; i++)
            {
                context.HistoryLearningDbset.AddOrUpdate(
                    new Model.HistoryLearning
                    {
                        IDHistoryLearning = i.ToString(),
                        IDStudent = "102T102",
                        Address = "Phan Bội Châu",
                        YearFrom = 1995 + i,
                        YearEnd = 1996 + i
                    });
            }
            for (int i = 1; i <= 12; i++)
            {
                context.HistoryLearningDbset.AddOrUpdate(
                    new Model.HistoryLearning
                    {
                        IDHistoryLearning = (i + 12).ToString(),
                        IDStudent = "102T101",
                        Address = "Phan Đình Phùng",
                        YearFrom = 1995 + i,
                        YearEnd = 1996 + i
                    });
            }
            context.SaveChanges();
        }
    }
}
